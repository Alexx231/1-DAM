<?php
//todas las operaciones que hagamos sobre la tabla libros se harán en esta clase, como insertar
require_once("../modelos/class_conexion.php");

class Usuario {
    
    private $nombre;
    private $plan_trabajo;
    private $peso_actual;
    private $categoria_peso;
    private $eventos_mes;
    private $horas_extra_mes;

    public function __construct($nombre, $plan_trabajo, $peso_actual, $categoria_peso, $eventos_mes, $horas_extra_mes) {
        $this->nombre = $nombre;
        $this->plan_trabajo = $plan_trabajo;
        $this->peso_actual = $peso_actual;
        $this->categoria_peso = $categoria_peso;
        $this->eventos_mes = $eventos_mes;
        $this->horas_extra_mes = $horas_extra_mes;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getPlanTrabajo() {
        return $this->plan_trabajo;
    }

    public function getPesoActual() {
        return $this->peso_actual;
    }

    public function getCategoriaPeso() {
        return $this->categoria_peso;
    }

    public function getNumEventos() {
        return $this->eventos_mes;
    }

    public function getHorasExtra() {
        return $this->horas_extra_mes;
    }
}

?>
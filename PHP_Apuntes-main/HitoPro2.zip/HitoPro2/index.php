<?php 

include("vistas/plantillas/cabeceras.php");

include("vistas/usuarios/crear.php");

include("vistas/plantillas/footer.php");


?>
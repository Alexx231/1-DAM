<?php

require_once '../modelos/Usuario.php';

if ($_POST['accion'] == 'crear') {

    $nombre = $_POST['nombre'];

    $plan_trabajo = $_POST['plan_trabajo'];

    $peso_actual = $_POST['peso_actual'];

    $categoria_peso = $_POST['categoria_peso'];

    $eventos_mes = $_POST['eventos_mes'];

    $horas_extra_mes = $_POST['horas_extra_mes'];

    // Crear una nueva instancia de Usuario
    $usuario = new Usuario($nombre, $plan_trabajo, $peso_actual, $categoria_peso, $eventos_mes, $horas_extra_mes);

    
}
?>




?>
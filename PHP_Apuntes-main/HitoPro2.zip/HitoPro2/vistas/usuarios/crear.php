
<?php



// Definamos el body de mi página	HTML
?>

<div class="container mt-5">
<h2>Crear Usuario</h2>
<form action ="/MVCPOOBIBLIOTECA/controladores/UsuariosControlador.php" method = "POST" class = "form">
    <div class = "mb-3">
        <label for = "nombre" class = "form-label">Nombre</label>
        <input type = "text" class = "form-control" id = "nombre" name = "nombre" required>
        <input type = "hidden" id ="accion" name = "accion" value = "crear">
    </div>
    <div class = "mb-3">
        <label for = "plan_trabajo" class = "form-label">Plan de Trabajo</label>
        <input type = "text" class = "form-control" id = "plan_trabajo" name = "plan_trabajo" required>
        
    </div>
    <div class = "mb-3">
        <label for = "peso_actual" class = "form-label">Peso Actual</label>
        <input type = "text" class = "form-control" id = "peso_actual" name = "peso_actual" required>

    </div>
    <div class = "mb-3">
        <label for = "categoria_peso" class = "form-label">Categoria Del peso</label>
        <input type = "text" class = "form-control" id = "categoria_peso" name = "categoria_peso" required>

    </div>
    <div class = "mb-3">
        <label for = "eventos_mes" class = "form-label">Eventos del mes</label>
        <input type = "text" class = "form-control" id = "eventos_mes" name = "eventos_mes" required>

    </div>
    <div class = "mb-3">
        <label for = "horas_extra_mes" class = "form-label">Horas extra del mes</label>
        <input type = "text" class = "form-control" id = "horas_extra_mes" name = "horas_extra_mes" required>

    </div>
    <button type = "submit" class = "btn btn-primary">Añadir</button>

</form>
</div>



